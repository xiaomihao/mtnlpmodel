__version__ = "0.9.1"

# for custom keras object auto discover
from seq2annotation import tf_contrib

import mtnlpmodel